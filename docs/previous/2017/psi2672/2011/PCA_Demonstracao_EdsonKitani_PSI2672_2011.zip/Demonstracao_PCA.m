%=======================================================================================
% Programa de Teste com PCA
% Grupo ICONE - LSI/USP 
% Edson Kitani  Prof. Dr. Emilio Hernandez 05/06/2011
%=======================================================================================
	clc;
	clf reset;
	close all;
	clear all;
   NN = 2;
   imdisp = 'n';
   continuar = 's';
   
	disp('Ser� solicitado o nome dos diret�rios que cont�m os conjuntos de treinamento.');
	disp('O nome devera�conter o caminho completo. Ex. C:\USP\FACES\Mulheres Normal\ ');
   disp('  ');
   
   
   a = input('Digite o nome do arquivo de dados : ','s');
   disp('  ');
  
	[Z,Znormal,maximo,imlin,imcol] = read_image_file(a,'*.jpg','n'); % Le o arquivo
	   
    [l,c] = size(Znormal);
   
	[Zx,P,K,M] = pca(Znormal,l-1); % Calcula o PCA
	aux = mat2gray(M);
   
% A rotina PCA retorna Zx que � uma matriz de m�dia zero com todas as imagens concatenadas
% Matriz P com os autovetores de Zx em cada coluna e cuja dimens�o � MN X M-1
% Vetor K de autovalores ordenados
% Vetor M com a m�dia global da matriz de imagens

% Reduz o numero de Componentes Principais

    P1 =P(:,1:30);
    
	Zpca = Zx*P1; % Matriz do espa�o de imagens PCA
    N = size(Zpca,1);
   
% Reconstruir uma imagem
   
   while(continuar == 's');
        
       	   disp('  ');
           numimg = input('Digite o numero da face desejada : ');
           disp('  ');
           q = Zpca(numimg,:);
           u = P1*q';
           vetor = mat2gray(u)' + aux;
           imagem = im2uint8(mat2gray(vetor));
           imback = (reshape(imagem, imlin,imcol));	
           figure(numimg); 
           imshow(imback);
           
       
     continuar = input('Continuar? ', 's');
	 disp('  ');
   end 