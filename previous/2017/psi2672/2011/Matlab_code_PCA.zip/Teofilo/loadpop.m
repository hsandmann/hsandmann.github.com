function X = loadpop(fileformat)
% X = makepop(fileformat)
%
% Function that creates the the population matrix X 
% whre each collum is a image of the database.
% The currend directory have to be the image database's directory

d=0; 
list=dir;
for c = 3:length(list),
   lname = length(list(c).name);
   if list(c).name(lname-2:lname) == fileformat,
      d=d+1;
      [img,map] = imread(list(c).name,fileformat);
      X(:,d) = img(:);
   end
end
X=double(X);
return
