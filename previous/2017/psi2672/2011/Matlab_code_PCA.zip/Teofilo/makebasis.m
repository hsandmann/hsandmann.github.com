function A = makebasis(X)
% A = makebase(X)
%
% Function that creates the "faces space", i. e. the
% basis of the space created throught the eigenvectors
% of the covariance matrix of the population matrix.
%
% X = Population matrix (as described in function
%     makepop().
%
% A = Orthogonal basis of the face space.

% Covariance matrix:
['Computing the covariance matrix of X (Cx)...']
Cx = cov(X'); % The matrix X must be transposed because each row 
              % of X ia a variable, and each column of X is an
              % observation (face).
              
['Computing the eigenfaces and eigenvalues of Cx...']
[V,D] = eig(Cx); % D = diagonal matrix with the eigenvalues 
                 % V = matrix in witch eacj column is the 
                 % respective eigenfaces:
                 % Cx*V = V*D.
                 
['Sorting the eigenvectors with respect to the decreasing order of the eigenvalues...'] 
eigenvalues = diag(D);
[eigenvalues, index] = sort(eigenvalues);
sizeV=size(V,2);
A=zeros(size(V));
for c=1:sizeV,
   eigenvalues_sort(c) = eigenvalues(sizeV-c+1);
   A(:,c) = V(:,index(sizeV-c+1)); % A is the eigenvector matrix sorted with respect to the eigenvalues.
end
return
