%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PCA Face Recognition Script %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% by Teofilo Emidio de Campos
% mailto:teo@ime.usp.br
% http://www.ime.usp.br/~teo
% ICQ# 6011445
% Creative Vision Research Group
% http://www.ime.usp.br/~cesar/creativision
% Computer Science Department
% Institute of Mathematics and Statistics
% Sao Paulo University - Brazil
% DCC - IME - USP
%
% Wed May 17  2000


% First it is necessary to normalize the size of
% all the image database.
% In the nest instructions, you have to
% set some input variables:
imageformat = '???';  % ??? = file format of the images on the database 
                      %       (e. g. tif);
imageheight = ???;    % ??? = desirable height (in pixels) for all 
                      %       the images in the database;
imagewide = ???;      % ??? = desirable wide (in pixels) for all the
                      %       images in the database;
                      % Remark: Due to the computational cost, 
                      %       it is recommended to use images smaller than 
                      %       48*48 pixels.
people = ???;         % ??? = how many people has the database;
                      %                      
test = ???;           % ??? = number of testing images per person.
                      %
neig = ???;           % ??? = number of eigenfaces for recognition.
                      %       if neig==-1, it will be used all the eigenfaces.

pcadir = pwd;
path(path, pcadir); % Set the current folder in the path.

cd ??? % ??? = image database folder's name. It is supposed that
% the current folder is the one where the pca functions and
% scripts are in.


['Normalizing the size of the images... ']
resize(imageheight, imagewide, imageformat);

cd ???x??? % ??? = folder where the function resize() stored the normalized images.

['Loading the population...']
X = loadpop(imageformat);
save  population X  % Stores the population matrix X in the file population.mat

['Creating the training matrix...'];
imgpperson = size(X,2)/people;  % Calculate the number of images per person.

rnd=999999;
elem=rnd*ones(test,1); % I is supposed that the database has less than 999999 images per person.
for c=1:test
   while find(rnd == elem),
      rnd = floor(1+(10*rand)*(imgpperson-1)/9);  % Ramdomly choose testing elements.
   end
   elem(c)=rnd;
end
save testelem elem; % Stores the sorted test elents in the file testelem.mat

% Creanting a new matrix Xbase that has only the trainning images:
sizetrain = [size(X,1) size(X,2)-people*length(elem)];
Xbasis=zeros(sizetrain);

sizetest = [size(X,1) people*length(elem)];
Xtest =zeros(sizetest);
d=1;
e=1;
for c=1:size(X,2),
   if isempty(find(mod(c,imgpperson)==mod(elem,imgpperson))),
      Xbasis(:,d) = X(:,c);
      d=d+1;
   else
      Xtest(:,e) = X(:,c);
      e=e+1;
   end   
end

['Creating the face spaces basis...']
A=makebasis(Xbasis);
save basis A  % Stores the basis A in the file basis.mat

['Creating the faces representation in face space...']
if neig==-1,
   Ytrain= A'*Xbasis;
   Ytest = A'*Xtest;
else
   Ytrain= A(:,1:neig)'*Xbasis;
   Ytest = A(:,1:neig)'*Xtest;
end

['Recognizing faces...']
classification=classif(Ytrain, Ytest);

['Recognition rate:']
success(classification, test, imgpperson-test)
