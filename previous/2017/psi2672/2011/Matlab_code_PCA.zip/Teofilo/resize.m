function resize(imageheight, imagewide, imageformat)
% resize(imageheight, imagewide)
%
% Resizes all the images in the database to 
% imageheight x imagewide
% This function must be called from the image database
% directory (use cd <directory>).
% Before using this function, it is necessary tocreate 
% a sub-folder called 'axb', where a = imageheight and 
% b = imagewide.

lista=dir;
for c = 3:length(lista),
   lname = length(lista(c).name);
   if lista(c).name(lname-2:lname) == imageformat,
      [img,map] = imread(lista(c).name, imageformat);
      face = imresize(img, [imageheight imagewide], 'nearest');
      outfile = ['.\',int2str(imageheight),'x', int2str(imagewide),'\', lista(c).name];
      imwrite(uint8(face), outfile,imageformat);
   end
end

