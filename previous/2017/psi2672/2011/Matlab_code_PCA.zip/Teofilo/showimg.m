function img=showimg(vet, height, wide)
% img=showimg(vet, height, wide)
%
% Function that shows the vector 'vet'
% as an image of size height * wide.

for col=1:wide,
   for lin = 1:height,
      img(lin, col) = vet((col-1)*height + lin);
   end
end

% Histogram stretch of the image:
minimum = min(min(img));
img = img - minimum + 1;
maximum = max(max(img));
coef = 256/(maximum); 

img = img*coef;

% Ploting the image: 
image(img); colormap(gray(256));
return
